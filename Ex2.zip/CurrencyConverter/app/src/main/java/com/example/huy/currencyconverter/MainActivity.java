package com.example.huy.currencyconverter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public void onClick(View v) {
        EditText moneyAmount = (EditText) findViewById(R.id.moneyAmount);
        Double MoneyToConvert = Double.parseDouble(moneyAmount.getText().toString());
        Double ratio = 0.0;
        switch (v.getId()) {
            case R.id.button:
                ratio = 0.000044;
                break;

            case R.id.button2:
                ratio = 0.000036;
                break;

            case R.id.button3:
                ratio = 0.0047;
                break;

            case R.id.button4:
                ratio = 23000.0;
                break;

            case R.id.button5:
                ratio = 0.81;
                break;

            case R.id.button6:
                ratio = 107.6;
                break;

            case R.id.button7:
                ratio = 0.0075;
                break;

            case R.id.button8:
                ratio = 211.38;
                break;

            case R.id.button9:
                ratio = 0.0093;
                break;

            case R.id.button10:
                ratio = 28000.0;
                break;

            case R.id.button11:
                ratio = 1.23;
                break;

            case R.id.button12:
                ratio = 132.5;
                break;

            default:
                break;
        }
        Double FinalAmount = MoneyToConvert * ratio;
        Toast.makeText(this, FinalAmount.toString(), Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
